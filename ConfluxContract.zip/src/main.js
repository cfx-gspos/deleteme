var ContractInstance = require('../helper/contract')({ contractName: "contractName", contractAddress: 'contractAddress' });

(async function () {
    //Set Value
    await ContractInstance.contract.set('Hello World').sendTransaction({ from: ContractInstance.account }).confirmed();
    //Get Value
    console.log(await ContractInstance.contract.get());
})();
