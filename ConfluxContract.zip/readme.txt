Install related package
npm install -g solc truffle


Step 1.Download and unzip file

Step 2[Important]. Write Contract

eg. Contract1.sol
    pragma solidity >=0.4.23;

    contract Contract1{

        string _field;
        function get()public view returns (string memory){
            return _field;
        }
        function set(string memory field)public{
            _field=field;
        }
    }

Step 3. Compile Contract and  Deploy Contract
truffle compile ;& node .\helper\deploy.js {ContractName}

Step 4[Important]. Call Contract
node  .\src\main.js
