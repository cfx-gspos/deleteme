module.exports = function (option) {
  var CONFIG = require('./conflux_config.json');
  const { Conflux, util } = require('js-conflux-sdk');
  const builtContract = require(`../build/contracts/${option.contractName}.json`);

  const cfx = new Conflux({
    url: CONFIG.url,
    defaultGasPrice: CONFIG.defaultGasPrice,
    defaultGas: CONFIG.defaultGas,
  });
  const contract = cfx.Contract({
    address: option.contractAddress,
    abi: builtContract.abi,
  });

  const account = cfx.Account(CONFIG.privateKey);

  var module = {};
  module.account = account;
  module.contract = contract;
  return module;
};