let contractName = process.argv.slice(2);

const CONFIG = require('./conflux_config.json');
const { Conflux } = require('js-conflux-sdk');

const builtContract = require(`../build/contracts/${contractName}.json`);

(async function () {
  const cfx = new Conflux({
    url: CONFIG.url,
    defaultGasPrice: CONFIG.defaultGasPrice,
    defaultGas: CONFIG.defaultGas,
  });

  const account = cfx.Account(CONFIG.privateKey);

  const contract = cfx.Contract({
    abi: builtContract.abi,
    bytecode: builtContract.bytecode,
  });

  const receipt = await contract.constructor()
    .sendTransaction({ from: account })
    .confirmed();
  console.log('Generated Contract Address is:\n' + receipt.contractCreated);
})()